
#ifdef USE_QUAL
if (pkgName == "qual")
{		
	return SWIGTYPE_p_QualExtension;
}
#endif	

