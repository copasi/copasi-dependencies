
#ifdef USE_QUAL
	// if (conName == "converter")
	//	return SWIGTYPE_p_converterType;
#endif	

