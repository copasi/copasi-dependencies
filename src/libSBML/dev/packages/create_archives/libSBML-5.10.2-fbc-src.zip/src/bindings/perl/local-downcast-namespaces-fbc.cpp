

#ifdef USE_FBC
if (pkgName == "fbc")
{		
	return SWIGTYPE_p_SBMLExtensionNamespacesT_FbcExtension_t;
}
#endif	

