
#ifdef USE_FBC
  if (conName == "SBML FBC to COBRA Converter")
     return SWIGTYPE_p_FbcToCobraConverter;
  if (conName == "SBML COBRA to FBC Converter")
     return SWIGTYPE_p_CobraToFbcConverter;
#endif	

