
#ifdef USE_FBC
FbcExtension::init();
#endif	

