
#ifdef USE_COMP
  if (conName == "SBML Comp Flattening Converter")
     return SWIGTYPE_p_CompFlatteningConverter;
#endif	

